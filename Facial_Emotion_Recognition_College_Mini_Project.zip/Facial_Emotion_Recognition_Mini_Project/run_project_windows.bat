@echo off
python -m pip install -r requirements.txt
echo Add an appropriately licensed dataset, then run: python train_model.py
echo After training, run: streamlit run app.py
pause
