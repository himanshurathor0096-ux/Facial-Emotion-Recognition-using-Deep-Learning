# Facial Expression Recognition — College Mini Project

## What it does
This educational project uses a Convolutional Neural Network (CNN) to classify an image into expression labels represented in a labeled training dataset. A Streamlit app allows an image upload and displays the predicted label and model scores.

**Important:** facial expressions do not reliably reveal a person's internal emotional state. Predictions can be inaccurate and must not be used for high-stakes decisions or surveillance. Use images only with permission.

## Files
- `app.py`: web interface
- `train_model.py`: CNN training script
- `requirements.txt`: dependencies
- `report/project_report.md`: editable report draft
- `presentation/presentation_outline.md`: presentation outline
- `viva_questions.md`: viva questions and answers
- `data/README.md`: dataset setup
- `models/README.md`: trained-model information

## Dataset and model
This ZIP does not contain facial image data or a trained model. Dataset licenses and redistribution rights vary, so obtain a dataset only from a source that permits your intended educational use. Place images in class-specific folders, for example:
```
data/fer_train/angry/
data/fer_train/disgust/
data/fer_train/fear/
data/fer_train/happy/
data/fer_train/neutral/
data/fer_train/sad/
data/fer_train/surprise/
```
Optionally, create `data/fer_validation/` with the same class folders. If it is absent, the training script uses an 80/20 split. The class folder names/order must match `CLASS_NAMES` in `app.py`; check `models/class_names.txt`.

## Run on a laptop
Use a TensorFlow-compatible Python version (Python 3.10/3.11 may be practical, depending on OS).
1. Extract ZIP and open a terminal in the project folder.
2. Install packages: `pip install -r requirements.txt`
3. Add a permitted dataset in the folder structure above.
4. Train: `python train_model.py`
5. Start the app: `streamlit run app.py`

Training may take time. Google Colab can be used for training if your laptop is limited. No dataset is downloaded automatically.

## Before submission
Replace report placeholders, record dataset source/license and class counts, train and run the project, add genuine screenshots, and report measured validation results rather than inventing accuracy.
